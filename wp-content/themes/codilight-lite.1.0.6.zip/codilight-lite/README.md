

Thank you for downloading our theme!


====================================================================
Description
====================================================================
Codilight Lite is a news magazine style WordPress theme from FameThemes which is a perfect option to create any kind of
magazine or blog websites.

====================================================================
SUPPORT
====================================================================
Support for this WordPress theme is conducted through the WordPress free theme support forum.
* FameThemes Website : http://www.famethemes.com
* Support Ticket: http://www.famethemes.com/dashboard/tickets/
* Support Forum for free theme: https://wordpress.org/support/theme/codilight-lite

====================================================================
DOCUMENTATION
====================================================================

Go to http://docs.famethemes.com/category/30-codilight-lite for theme documentation & troubleshooting guides.

====================================================================
LICENSES
====================================================================

* Underscores
Based on Underscores http://underscores.me/, (C) 2012-2015 Automattic, Inc., [GPLv2 or later](https://www.gnu.org/licenses/gpl-2.0.html)

* Normalize
normalize.css http://necolas.github.io/normalize.css/, (C) 2012-2015 Nicolas Gallagher and Jonathan Neal, [MIT](http://opensource.org/licenses/MIT)

* Google Fonts

Source: https://www.google.com/fonts/specimen/Raleway
License: SIL Open Font License, 1.1 - scripts.sil.org/OFL

Source: https://www.google.com/fonts/specimen/Open+Sans
License: SIL Open Font License, 1.1 - scripts.sil.org/OFL

* FitVids
Source: https://github.com/davatron5000/FitVids.js/blob/master/jquery.fitvids.js
License: Released under the WTFPL license - http://sam.zoy.org/wtfpl/

* FontAwesome
Source: https://fortawesome.github.io/Font-Awesome/
License: GPL - https://fortawesome.github.io/Font-Awesome/license/

* Slickjs
Source: https://github.com/kenwheeler/slick
License: MIT: https://github.com/kenwheeler/slick/blob/master/LICENSE

* Screenshot Images
Pixabay: https://pixabay.com/en/service/terms/ (http://creativecommons.org/publicdomain/zero/1.0 - CC0)
Pexels: https://www.pexels.com/photo-license/ (http://creativecommons.org/publicdomain/zero/1.0 - CC0)

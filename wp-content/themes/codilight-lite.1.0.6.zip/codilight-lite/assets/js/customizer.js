
jQuery( document ).ready( function( $ ){
    $('#customize-info .accordion-section-title').append('<a target="_blank" style="text-transform: uppercase; background: #D54E21; color: #fff; font-size: 10px; line-height: 14px; padding: 2px 5px; display: inline-block;" href="https://www.famethemes.com/themes/codilight/?utm_source=codilight_lite_customizer&utm_medium=text_link&utm_campaign=codilight_lite">Upgrade to Codilight Premium</a>');
} );
